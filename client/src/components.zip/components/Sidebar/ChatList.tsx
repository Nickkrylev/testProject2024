import React from "react";
import ChatListItem from "./ChatListItem";

const ChatList: React.FC = () => {
  const chats = [
    {
      id: 1,
      avatar: "https://via.placeholder.com/50",
      name: "Friendly Hub",
      lastMessage: "Hello!",
      time: "10:32 AM",
      unreadCount: 2,
    },
    {
      id: 2,
      avatar: "https://via.placeholder.com/50",
      name: "Салатний лістік",
      lastMessage: "Я такой ужасный...",
      time: "11:58 PM",
      unreadCount: 0,
    },
  ];

  return (
    <div className="flex-grow overflow-y-auto">
      {chats.map((chat) => (
        <ChatListItem key={chat.id} {...chat} />
      ))}
    </div>
  );
};

export default ChatList;
