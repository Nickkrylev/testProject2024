import React from "react";
import SearchBar from "./SearchBar";
import ChatList from "./ChatList";
import UserProfile from "./UserProfile";

const Sidebar: React.FC = () => {
  return (
    <div className="flex flex-col w-1/4 bg-gray-100 h-screen">
      <UserProfile />
      <SearchBar />
      <ChatList />
    </div>
  );
};

export default Sidebar;
