import React from "react";

interface ChatListItemProps {
  avatar: string;
  name: string;
  lastMessage: string;
  time: string;
  unreadCount: number;
}

const ChatListItem: React.FC<ChatListItemProps> = ({
  avatar,
  name,
  lastMessage,
  time,
  unreadCount,
}) => {
  return (
    <div className="flex items-center p-2 hover:bg-gray-200 cursor-pointer">
      <img
        src={avatar}
        alt={name}
        className="w-12 h-12 rounded-full mr-3"
      />
      <div className="flex-1">
        <div className="flex justify-between">
          <span className="font-medium">{name}</span>
          <span className="text-sm text-gray-500">{time}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-sm text-gray-600 truncate">{lastMessage}</span>
          {unreadCount > 0 && (
            <span className="text-xs bg-blue-500 text-white rounded-full px-2 py-1 ml-2">
              {unreadCount}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default ChatListItem;
