import React from "react";

const UserProfile: React.FC = () => {
  return (
    <div className="flex items-center justify-between p-3 bg-gray-200">
      <div className="flex items-center">
        <img
          src="https://via.placeholder.com/50"
          alt="User Avatar"
          className="w-12 h-12 rounded-full"
        />
        <span className="ml-3 font-medium">User Name</span>
      </div>
      <button className="text-gray-600 hover:text-gray-800 focus:outline-none">
        ⚙️
      </button>
    </div>
  );
};

export default UserProfile;
