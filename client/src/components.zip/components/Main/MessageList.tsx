import React, { useState } from "react";
import MessageItem from "./MessageItem";
import Modal from "../Modal/Modal";

interface Message {
  id: number;
  text: string;
  timestamp: string;
  isOwn: boolean;
  attachments: string[];
}

interface MessageListProps {
  messages: Message[];
}

const MessageList: React.FC<MessageListProps> = ({ messages }) => {
  const [isModalOpen, setModalOpen] = useState(false);
  const [currentMessage, setCurrentMessage] = useState<string | null>(null);

  const handleLongClick = (messageText: string) => {
    setCurrentMessage(messageText);
    setModalOpen(true);
  };

  // Заглушка: только закрываем модалку, реальной логики удаления/изменения нет
  const handleEdit = () => {
    alert(`Редактировать сообщение: ${currentMessage}`);
    setModalOpen(false);
  };

  const handleDelete = () => {
    alert(`Удалить сообщение: ${currentMessage}`);
    setModalOpen(false);
  };

  return (
    <div className="flex-grow overflow-y-auto p-4 bg-gray-50">
      {messages.map((message) => (
        <div
          key={message.id}
          onContextMenu={(e) => {
            e.preventDefault();
            handleLongClick(message.text);
          }}
        >
          <MessageItem {...message} />
        </div>
      ))}
      <Modal isOpen={isModalOpen} onClose={() => setModalOpen(false)}>
        <h3 className="font-bold mb-4">Выберите действие</h3>
        <p className="text-gray-600 mb-4">{currentMessage}</p>
        <button
          className="bg-green-500 text-white px-4 py-2 rounded-md hover:bg-green-600"
          onClick={handleEdit}
        >
          Изменить
        </button>
        <button
          className="ml-2 bg-red-500 text-white px-4 py-2 rounded-md hover:bg-red-600"
          onClick={handleDelete}
        >
          Удалить
        </button>
        <button
          className="ml-2 bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600"
          onClick={() => setModalOpen(false)}
        >
          Закрыть
        </button>
      </Modal>
    </div>
  );
};

export default MessageList;
