import React from "react";

interface MessageItemProps {
  text: string;
  timestamp: string;
  isOwn: boolean;
  attachments: string[];
}

const MessageItem: React.FC<MessageItemProps> = ({
  text,
  timestamp,
  isOwn,
  attachments,
}) => {
  return (
    <div
      className={`flex items-start ${
        isOwn ? "justify-end" : "justify-start"
      } mb-4`}
    >
      {!isOwn && (
        <img
          src="https://via.placeholder.com/40"
          alt="Avatar"
          className="w-10 h-10 rounded-full mr-3"
        />
      )}
      <div
        className={`max-w-xs p-3 rounded-lg ${
          isOwn ? "bg-blue-500 text-white" : "bg-gray-200 text-black"
        }`}
      >
        <p>{text}</p>
        {attachments.map((url, index) => (
          <img
            key={index}
            src={url}
            alt={`Attachment ${index + 1}`}
            className="mt-2 rounded-lg"
          />
        ))}
        <span className="block text-xs text-gray-500 mt-1">{timestamp}</span>
      </div>
    </div>
  );
};

export default MessageItem;
