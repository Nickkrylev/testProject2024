import React, { useState } from "react";
import ChatHeader from "./ChatHeader";
import MessageList from "./MessageList";
import MessageInput from "./MessageInput";
import PinnedMessages from "../Modal/PinnedMessages";

interface IMessage {
  id: number;
  text: string;
  timestamp: string;
  isOwn: boolean;
  attachments: string[];
}

const ChatWindow: React.FC = () => {
  // Пример начальных сообщений
  const [messages, setMessages] = useState<IMessage[]>([
    {
      id: 1,
      text: "Привет! Как дела?",
      timestamp: "11:23 PM",
      isOwn: false,
      attachments: [],
    },
    {
      id: 2,
      text: "Все хорошо, а у тебя?",
      timestamp: "11:25 PM",
      isOwn: true,
      attachments: ["https://via.placeholder.com/100"],
    },
  ]);

  // Пример закреплённых сообщений
  const [pinnedMessages, setPinnedMessages] = useState([
    { id: 1, text: "Не забудь про встречу в 12:00" },
    { id: 2, text: "Ссылка на документ: https://example.com" },
  ]);

  // Функция отправки нового сообщения (вызывается в MessageInput)
  const handleSendMessage = (text: string, attachmentFiles: File[]) => {
    // Не отправляем сообщение, если пусто и нет файлов
    if (!text && attachmentFiles.length === 0) return;

    const newMessage: IMessage = {
      id: Date.now(),
      text,
      timestamp: new Date().toLocaleTimeString(),
      isOwn: true,
      // В реальном приложении файлы нужно загружать на сервер;
      // Здесь для примера используем локальные URL
      attachments: attachmentFiles.map((file) => URL.createObjectURL(file)),
    };

    setMessages((prev) => [...prev, newMessage]);
  };

  return (
    <div className="flex flex-col flex-grow bg-white h-screen">
      <ChatHeader />
      {/* Закреплённые сообщения */}
      <PinnedMessages messages={pinnedMessages} />

      {/* Список сообщений */}
      <MessageList messages={messages} />

      {/* Поле ввода и прикрепления файлов */}
      <MessageInput onSend={handleSendMessage} />
    </div>
  );
};

export default ChatWindow;
