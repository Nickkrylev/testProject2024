import React, { useState } from "react";
import FilePreview from "../Modal/FilePreview";

interface MessageInputProps {
  onSend: (text: string, attachments: File[]) => void;
}

const MessageInput: React.FC<MessageInputProps> = ({ onSend }) => {
  const [message, setMessage] = useState("");
  const [attachments, setAttachments] = useState<File[]>([]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      setAttachments([...attachments, ...Array.from(e.target.files)]);
    }
  };

  const handleRemoveFile = (index: number) => {
    setAttachments(attachments.filter((_, i) => i !== index));
  };

  // Эта функция вызывается при клике на кнопку отправки
  const handleSend = () => {
    onSend(message, attachments);
    // Сбрасываем поля
    setMessage("");
    setAttachments([]);
  };

  return (
    <div className="p-4 border-t bg-gray-100">
      <div className="flex items-center space-x-3">
        <input
          type="text"
          placeholder="Напишите сообщение..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          className="flex-grow p-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <label className="p-2 bg-gray-200 rounded-md cursor-pointer hover:bg-gray-300">
          📎
          <input
            type="file"
            multiple
            onChange={handleFileChange}
            className="hidden"
          />
        </label>
        <button
          onClick={handleSend}
          className="p-2 bg-blue-500 text-white rounded-md hover:bg-blue-600"
        >
          ➤
        </button>
      </div>
      <FilePreview files={attachments} onRemove={handleRemoveFile} />
    </div>
  );
};

export default MessageInput;
