import React from "react";

const ChatHeader: React.FC = () => {
  return (
    <div className="flex items-center justify-between p-4 bg-gray-200 border-b">
      <div className="flex items-center">
        <img
          src="https://via.placeholder.com/50"
          alt="Chat Avatar"
          className="w-10 h-10 rounded-full mr-3"
        />
        <div>
          <h1 className="text-lg font-medium">Салатний лістік</h1>
        </div>
      </div>
      
    </div>
  );
};

export default ChatHeader;
